#include "Empleado.h"



int main() {
	Empleado a;
	//a.writeAll();
	a.readAll();

	

}