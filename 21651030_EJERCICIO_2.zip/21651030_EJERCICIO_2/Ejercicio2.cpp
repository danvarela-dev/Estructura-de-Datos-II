#include "Persona.h"


int main() {

	Persona app;
	app.writeAll();
	//app.readAll();

}